# データベース設定
db_host = "localhost"
db_port = 3306
db_user = "root"
db_password = "tkhtnk29"
db_name = "mydb"
# table名は削除　複数table(userとtasks)を使用するため
